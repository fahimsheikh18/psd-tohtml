// bx slider


$(document).ready(function(){
  $('.slider-area').bxSlider();
  $('#main-menu').meanmenu(
    {
      meanmenucontainer:'#mobile-menu',
      meanScreenWidth:991,
    }
  );
});


